package service

import (
	"github.com/i-AbdullahAsim/free-genai-bootcamp-2025/Week_1/backend_go/internal/repository"
	"github.com/i-AbdullahAsim/free-genai-bootcamp-2025/Week_1/backend_go/internal/models"
)

type WordService struct {
	wordRepo repository.WordRepository
	groupRepo repository.GroupRepository
}

func NewWordService(wordRepo repository.WordRepository, groupRepo repository.GroupRepository) *WordService {
	return &WordService{
		wordRepo: wordRepo,
		groupRepo: groupRepo,
	}
}

// ListWords retrieves all words
func (s *WordService) ListWords(page, pageSize int) ([]models.Word, int64, error) {
	return s.wordRepo.FindWords(page, pageSize)
}

// GetWord retrieves a word by ID
func (s *WordService) GetWord(id uint) (*models.Word, error) {
	return s.wordRepo.FindWordByID(id)
}

// CreateWord creates a new word
func (s *WordService) CreateWord(word *models.Word) error {
	return s.wordRepo.CreateWord(word)
}

// UpdateWord updates an existing word
func (s *WordService) UpdateWord(word *models.Word) error {
	return s.wordRepo.UpdateWord(word)
}

// DeleteWord deletes a word by ID
func (s *WordService) DeleteWord(id uint) error {
	return s.wordRepo.DeleteWord(id)
}

// AddWordToGroup adds a word to a group
func (s *WordService) AddWordToGroup(wordID uint, groupID uint) error {
	word, err := s.wordRepo.FindWordByID(wordID)
	if err != nil {
		return err
	}
	
	group, err := s.groupRepo.FindGroupByID(groupID)
	if err != nil {
		return err
	}
	
	word.Groups = append(word.Groups, *group)
	return s.wordRepo.UpdateWord(word)
}

// RemoveWordFromGroup removes a word from a group
func (s *WordService) RemoveWordFromGroup(wordID uint, groupID uint) error {
	word, err := s.wordRepo.FindWordByID(wordID)
	if err != nil {
		return err
	}
	
	newGroups := make([]models.Group, 0)
	for _, g := range word.Groups {
		if g.ID != groupID {
			newGroups = append(newGroups, g)
		}
	}
	word.Groups = newGroups
	return s.wordRepo.UpdateWord(word)
}