package db

import (
	"log"
	"os"
	"sync"
	"time"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"github.com/i-AbdullahAsim/free-genai-bootcamp-2025/Week_1/backend_go/internal/models"
)

var (
	dbInstance *gorm.DB
	once       sync.Once
)

// GetDB returns the global database instance
func GetDB() *gorm.DB {
	once.Do(func() {
		db, err := InitializeDB()
		if err != nil {
			log.Fatal("Failed to initialize database:", err)
		}
		dbInstance = db
	})
	return dbInstance
}

// InitializeDB initializes the database connection and performs migrations
func InitializeDB() (*gorm.DB, error) {
	// Set up logger
	newLogger := logger.New(
		log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
		logger.Config{
			SlowThreshold: time.Second, // Slow SQL threshold
			LogLevel:      logger.Info, // Log level
			Colorful:      true,        // Disable color
		},
	)

	// Connect to SQLite database with WSL-compatible settings
	db, err := gorm.Open(sqlite.Open("words.db?_journal=DELETE&_timeout=5000&_busy_timeout=5000&_foreign_keys=1&_locking=NORMAL"), &gorm.Config{
		Logger: newLogger,
	})
	if err != nil {
		return nil, err
	}

	// Get raw SQL database connection
	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}

	// Set connection pool settings
	sqlDB.SetMaxIdleConns(1) // SQLite only supports one connection at a time
	sqlDB.SetMaxOpenConns(1) // SQLite only supports one connection at a time
	sqlDB.SetConnMaxLifetime(time.Hour)

	// Apply SQL migrations
	if err := ApplyMigrations(sqlDB); err != nil {
		return nil, err
	}

	// Auto-migrate models as a fallback
	if err := db.AutoMigrate(
		&models.Word{},
		&models.Group{},
		&models.WordGroup{},
		&models.StudySession{},
		&models.StudyActivity{},
		&models.WordReviewItem{},
	); err != nil {
		return nil, err
	}

	return db, nil
}
