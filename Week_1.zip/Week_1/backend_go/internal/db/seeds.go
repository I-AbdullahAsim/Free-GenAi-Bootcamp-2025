package db

// Temporary placeholder to satisfy Go compiler
func init() {}