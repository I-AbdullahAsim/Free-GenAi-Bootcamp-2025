package models

import "gorm.io/gorm"

// DB is the global database instance
var DB *gorm.DB
