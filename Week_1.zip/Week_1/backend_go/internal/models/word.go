package models

import (
	"database/sql/driver"
	"encoding/json"
	"errors"

	"gorm.io/gorm"
)

// StringSlice is a custom type for handling string arrays in JSON
type StringSlice []string

// Value implements the driver.Valuer interface
func (s StringSlice) Value() (driver.Value, error) {
	if len(s) == 0 {
		return "[]", nil
	}
	return json.Marshal(s)
}

// Scan implements the sql.Scanner interface
func (s *StringSlice) Scan(value interface{}) error {
	if value == nil {
		*s = StringSlice{}
		return nil
	}

	bytes, ok := value.([]byte)
	if !ok {
		return errors.New("type assertion to []byte failed")
	}

	return json.Unmarshal(bytes, s)
}

type Word struct {
	gorm.Model
	ArabicWord      string           `gorm:"not null" json:"arabic_word"`
	EnglishWord     string           `gorm:"not null" json:"english_word"`
	Parts           StringSlice      `gorm:"type:json" json:"parts"`
	Groups          []Group          `gorm:"many2many:word_groups;" json:"groups,omitempty"`
	WordReviewItems []WordReviewItem `gorm:"foreignKey:WordID" json:"word_review_items,omitempty"`
}
