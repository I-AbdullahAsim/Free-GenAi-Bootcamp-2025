package models

import (
    "gorm.io/gorm"
)

type Group struct {
    gorm.Model
    Name         string         `gorm:"not null"`
    Words        []Word         `gorm:"many2many:word_groups;"`
    StudySessions []StudySession `gorm:"foreignKey:GroupID;references:ID"`
}