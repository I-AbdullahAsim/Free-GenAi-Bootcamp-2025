package models

// Settings model is defined in models.go
// Use the models from models.go instead of defining them here

// Model exports all models for external packages
var _ = []interface{}{
    (*Settings)(nil),
}
