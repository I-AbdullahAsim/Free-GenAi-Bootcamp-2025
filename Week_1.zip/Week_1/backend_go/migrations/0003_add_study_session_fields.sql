-- Add additional fields to study_sessions table
ALTER TABLE study_sessions ADD COLUMN start_time TIMESTAMP;
ALTER TABLE study_sessions ADD COLUMN end_time TIMESTAMP;

-- Update existing records with default values
UPDATE study_sessions 
SET start_time = created_at,
    end_time = datetime(created_at, '+30 minutes')
WHERE start_time IS NULL; 