-- Remove additional fields from study_sessions table
ALTER TABLE study_sessions DROP COLUMN start_time;
ALTER TABLE study_sessions DROP COLUMN end_time; 