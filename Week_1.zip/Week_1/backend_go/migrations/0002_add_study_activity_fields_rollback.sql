-- Remove additional fields from study_activities table
ALTER TABLE study_activities DROP COLUMN name;
ALTER TABLE study_activities DROP COLUMN description;
ALTER TABLE study_activities DROP COLUMN thumbnail_url;
ALTER TABLE study_activities DROP COLUMN launch_url; 