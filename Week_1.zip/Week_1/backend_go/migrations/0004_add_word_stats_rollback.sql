-- Remove statistics fields from words table
ALTER TABLE words DROP COLUMN correct_count;
ALTER TABLE words DROP COLUMN wrong_count;

-- Remove statistics index
DROP INDEX IF EXISTS idx_words_stats; 