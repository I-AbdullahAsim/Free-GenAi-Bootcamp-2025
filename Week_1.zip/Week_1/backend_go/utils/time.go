package utils

import (
	"time"
)

const (
	// DefaultTimeFormat is the default format for time strings
	DefaultTimeFormat = "2006-01-02 15:04:05"
	// DefaultDateFormat is the default format for date strings
	DefaultDateFormat = "2006-01-02"
)

// FormatTime formats a time.Time to a string using the default format
func FormatTime(t time.Time) string {
	return t.Format(DefaultTimeFormat)
}

// FormatDate formats a time.Time to a date string
func FormatDate(t time.Time) string {
	return t.Format(DefaultDateFormat)
}

// ParseTime parses a time string using the default format
func ParseTime(timeStr string) (time.Time, error) {
	return time.Parse(DefaultTimeFormat, timeStr)
}

// ParseDate parses a date string
func ParseDate(dateStr string) (time.Time, error) {
	return time.Parse(DefaultDateFormat, dateStr)
}

// IsToday checks if a time is today
func IsToday(t time.Time) bool {
	now := time.Now()
	return t.Year() == now.Year() && t.Month() == now.Month() && t.Day() == now.Day()
}

// IsSameDay checks if two times are on the same day
func IsSameDay(t1, t2 time.Time) bool {
	return t1.Year() == t2.Year() && t1.Month() == t2.Month() && t1.Day() == t2.Day()
}

// StartOfDay returns the start of the day for a given time
func StartOfDay(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
}

// EndOfDay returns the end of the day for a given time
func EndOfDay(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 23, 59, 59, 999999999, t.Location())
}

// DaysBetween returns the number of days between two times
func DaysBetween(t1, t2 time.Time) int {
	t1 = StartOfDay(t1)
	t2 = StartOfDay(t2)
	return int(t2.Sub(t1).Hours() / 24)
}

// IsWithinLastNDays checks if a time is within the last N days
func IsWithinLastNDays(t time.Time, n int) bool {
	now := time.Now()
	return t.After(now.AddDate(0, 0, -n)) && !t.After(now)
}

func init() {}
